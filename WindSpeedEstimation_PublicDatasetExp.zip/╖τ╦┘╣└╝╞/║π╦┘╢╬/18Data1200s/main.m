clc
clear 
close all



%% ��������
load v.txt;
v = v(:,2);

load pitch.txt;
beta = pitch(:,2);

load dfa.txt;
dfa = dfa(:,2);

load pitchRate.txt;
betaRate = pitchRate(:,2);

load vfa.txt;
vfa = vfa(:,2);

load afa.txt;
afa = afa(:,2);

%% �����������й�һ������
n = length(v);
variables = [v beta dfa betaRate vfa afa];
variables_norm = (variables - repmat(min(variables), n, 1)) ./ repmat((max(variables) - min(variables)), n, 1);%max()��ž���    
v_norm = variables_norm(:,1);
beta_norm = variables_norm(:,2);
dfa_norm = variables_norm(:,3);
betaRate_norm = variables_norm(:,4);
vfa_norm = variables_norm(:,5);
afa_norm = variables_norm(:,6);

%% ������ٺͽ����֮��Ļ���Ϣ
num_v_norm_0 = 0;
num_v_norm_1 = 0;
for i = 1:n
    if v_norm(i) <= mean(v_norm)
        num_v_norm_0 = num_v_norm_0 +1;
    end 
     
    if v_norm(i) > mean(v_norm)
        num_v_norm_1 = num_v_norm_1 +1;
    end
end

num_beta_norm_0 = 0;
num_beta_norm_1 = 0;
for i = 1:n
    if beta_norm(i) <= mean(beta_norm)
        num_beta_norm_0 = num_beta_norm_0 +1;
    end 
     
    if beta_norm(i) > mean(beta_norm)
        num_beta_norm_1 = num_beta_norm_1 +1;
    end
end

U0 = num_v_norm_0 + num_beta_norm_0;
U1 = num_v_norm_0 + num_beta_norm_1;
U2 = num_v_norm_1 + num_beta_norm_0;
U3 = num_v_norm_1 + num_beta_norm_1;
L = U0 + U1 + U2 + U3;

P_v_norm_0 = (U0 + U1)/L;
P_v_norm_1 = (U2 + U3)/L;
P_beta_norm_0 = (U0 + U2)/L;
P_beta_norm_1 = (U1 + U3)/L;

P_v_norm_0_beta_norm_0 = U0/L;
P_v_norm_1_beta_norm_0 = U2/L;
P_v_norm_0_beta_norm_1 = U1/L;
P_v_norm_1_beta_norm_1 = U3/L;

MI_v_beta = P_v_norm_0_beta_norm_0 * log2(P_v_norm_0_beta_norm_0/(P_v_norm_0*P_beta_norm_0)) + ...
            P_v_norm_0_beta_norm_1 * log2(P_v_norm_0_beta_norm_1/(P_v_norm_0*P_beta_norm_1)) + ...
            P_v_norm_1_beta_norm_0 * log2(P_v_norm_1_beta_norm_0/(P_v_norm_1*P_beta_norm_0)) + ...
            P_v_norm_1_beta_norm_1 * log2(P_v_norm_1_beta_norm_1/(P_v_norm_1*P_beta_norm_1)); 


        
%% ������ٺ�����ǰ��λ��֮��Ļ���Ϣ
num_v_norm_0 = 0;
num_v_norm_1 = 0;
for i = 1:n
    if v_norm(i) <= mean(v_norm)
        num_v_norm_0 = num_v_norm_0 +1;
    end 
     
    if v_norm(i) > mean(v_norm)
        num_v_norm_1 = num_v_norm_1 +1;
    end
end

num_dfa_norm_0 = 0;
num_dfa_norm_1 = 0;
for i = 1:n
    if dfa_norm(i) <= mean(dfa_norm)
        num_dfa_norm_0 = num_dfa_norm_0 +1;
    end 
     
    if dfa_norm(i) > mean(dfa_norm)
        num_dfa_norm_1 = num_dfa_norm_1 +1;
    end
end

U0 = num_v_norm_0 + num_dfa_norm_0;
U1 = num_v_norm_0 + num_dfa_norm_1;
U2 = num_v_norm_1 + num_dfa_norm_0;
U3 = num_v_norm_1 + num_dfa_norm_1;
L = U0 + U1 + U2 + U3;

P_v_norm_0 = (U0 + U1)/L;
P_v_norm_1 = (U2 + U3)/L;
P_dfa_norm_0 = (U0 + U2)/L;
P_dfa_norm_1 = (U1 + U3)/L;

P_v_norm_0_dfa_norm_0 = U0/L;
P_v_norm_1_dfa_norm_0 = U2/L;
P_v_norm_0_dfa_norm_1 = U1/L;
P_v_norm_1_dfa_norm_1 = U3/L;

MI_v_dfa = P_v_norm_0_dfa_norm_0 * log2(P_v_norm_0_dfa_norm_0/(P_v_norm_0*P_dfa_norm_0)) + ...
            P_v_norm_0_dfa_norm_1 * log2(P_v_norm_0_dfa_norm_1/(P_v_norm_0*P_dfa_norm_1)) + ...
            P_v_norm_1_dfa_norm_0 * log2(P_v_norm_1_dfa_norm_0/(P_v_norm_1*P_dfa_norm_0)) + ...
            P_v_norm_1_dfa_norm_1 * log2(P_v_norm_1_dfa_norm_1/(P_v_norm_1*P_dfa_norm_1));  
        

        
%% ������ٺͽ���Ǳ仯��֮��Ļ���Ϣ
num_v_norm_0 = 0;
num_v_norm_1 = 0;
for i = 1:n
    if v_norm(i) <= mean(v_norm)
        num_v_norm_0 = num_v_norm_0 +1;
    end 
     
    if v_norm(i) > mean(v_norm)
        num_v_norm_1 = num_v_norm_1 +1;
    end
end

num_betaRate_norm_0 = 0;
num_betaRate_norm_1 = 0;
for i = 1:n
    if betaRate_norm(i) <= mean(betaRate_norm)
        num_betaRate_norm_0 = num_betaRate_norm_0 +1;
    end 
     
    if betaRate_norm(i) > mean(betaRate_norm)
        num_betaRate_norm_1 = num_betaRate_norm_1 +1;
    end
end

U0 = num_v_norm_0 + num_betaRate_norm_0;
U1 = num_v_norm_0 + num_betaRate_norm_1;
U2 = num_v_norm_1 + num_betaRate_norm_0;
U3 = num_v_norm_1 + num_betaRate_norm_1;
L = U0 + U1 + U2 + U3;

P_v_norm_0 = (U0 + U1)/L;
P_v_norm_1 = (U2 + U3)/L;
P_betaRate_norm_0 = (U0 + U2)/L;
P_betaRate_norm_1 = (U1 + U3)/L;

P_v_norm_0_betaRate_norm_0 = U0/L;
P_v_norm_1_betaRate_norm_0 = U2/L;
P_v_norm_0_betaRate_norm_1 = U1/L;
P_v_norm_1_betaRate_norm_1 = U3/L;

MI_v_betaRate = P_v_norm_0_betaRate_norm_0 * log2(P_v_norm_0_betaRate_norm_0/(P_v_norm_0*P_betaRate_norm_0)) + ...
                P_v_norm_0_betaRate_norm_1 * log2(P_v_norm_0_betaRate_norm_1/(P_v_norm_0*P_betaRate_norm_1)) + ...
                P_v_norm_1_betaRate_norm_0 * log2(P_v_norm_1_betaRate_norm_0/(P_v_norm_1*P_betaRate_norm_0)) + ...
                P_v_norm_1_betaRate_norm_1 * log2(P_v_norm_1_betaRate_norm_1/(P_v_norm_1*P_betaRate_norm_1));              



%% ������ٺ�����ǰ���ٶ�֮��Ļ���Ϣ
num_v_norm_0 = 0;
num_v_norm_1 = 0;
for i = 1:n
    if v_norm(i) <= mean(v_norm)
        num_v_norm_0 = num_v_norm_0 +1;
    end 
     
    if v_norm(i) > mean(v_norm)
        num_v_norm_1 = num_v_norm_1 +1;
    end
end

num_vfa_norm_0 = 0;
num_vfa_norm_1 = 0;
for i = 1:n
    if vfa_norm(i) <= mean(vfa_norm)
        num_vfa_norm_0 = num_vfa_norm_0 +1;
    end 
     
    if vfa_norm(i) > mean(vfa_norm)
        num_vfa_norm_1 = num_vfa_norm_1 +1;
    end
end

U0 = num_v_norm_0 + num_vfa_norm_0;
U1 = num_v_norm_0 + num_vfa_norm_1;
U2 = num_v_norm_1 + num_vfa_norm_0;
U3 = num_v_norm_1 + num_vfa_norm_1;
L = U0 + U1 + U2 + U3;

P_v_norm_0 = (U0 + U1)/L;
P_v_norm_1 = (U2 + U3)/L;
P_vfa_norm_0 = (U0 + U2)/L;
P_vfa_norm_1 = (U1 + U3)/L;

P_v_norm_0_vfa_norm_0 = U0/L;
P_v_norm_1_vfa_norm_0 = U2/L;
P_v_norm_0_vfa_norm_1 = U1/L;
P_v_norm_1_vfa_norm_1 = U3/L;

MI_v_vfa = P_v_norm_0_vfa_norm_0 * log2(P_v_norm_0_vfa_norm_0/(P_v_norm_0*P_vfa_norm_0)) + ...
                P_v_norm_0_vfa_norm_1 * log2(P_v_norm_0_vfa_norm_1/(P_v_norm_0*P_vfa_norm_1)) + ...
                P_v_norm_1_vfa_norm_0 * log2(P_v_norm_1_vfa_norm_0/(P_v_norm_1*P_vfa_norm_0)) + ...
                P_v_norm_1_vfa_norm_1 * log2(P_v_norm_1_vfa_norm_1/(P_v_norm_1*P_vfa_norm_1));              



%% ������ٺ�����ǰ����ٶ�֮��Ļ���Ϣ
num_v_norm_0 = 0;
num_v_norm_1 = 0;
for i = 1:n
    if v_norm(i) <= mean(v_norm)
        num_v_norm_0 = num_v_norm_0 +1;
    end 
     
    if v_norm(i) > mean(v_norm)
        num_v_norm_1 = num_v_norm_1 +1;
    end
end

num_afa_norm_0 = 0;
num_afa_norm_1 = 0;
for i = 1:n
    if afa_norm(i) <= mean(afa_norm)
        num_afa_norm_0 = num_afa_norm_0 +1;
    end 
     
    if afa_norm(i) > mean(afa_norm)
        num_afa_norm_1 = num_afa_norm_1 +1;
    end
end

U0 = num_v_norm_0 + num_afa_norm_0;
U1 = num_v_norm_0 + num_afa_norm_1;
U2 = num_v_norm_1 + num_afa_norm_0;
U3 = num_v_norm_1 + num_afa_norm_1;
L = U0 + U1 + U2 + U3;

P_v_norm_0 = (U0 + U1)/L;
P_v_norm_1 = (U2 + U3)/L;
P_afa_norm_0 = (U0 + U2)/L;
P_afa_norm_1 = (U1 + U3)/L;

P_v_norm_0_afa_norm_0 = U0/L;
P_v_norm_1_afa_norm_0 = U2/L;
P_v_norm_0_afa_norm_1 = U1/L;
P_v_norm_1_afa_norm_1 = U3/L;

MI_v_afa = P_v_norm_0_afa_norm_0 * log2(P_v_norm_0_afa_norm_0/(P_v_norm_0*P_afa_norm_0)) + ...
                P_v_norm_0_afa_norm_1 * log2(P_v_norm_0_afa_norm_1/(P_v_norm_0*P_afa_norm_1)) + ...
                P_v_norm_1_afa_norm_0 * log2(P_v_norm_1_afa_norm_0/(P_v_norm_1*P_afa_norm_0)) + ...
                P_v_norm_1_afa_norm_1 * log2(P_v_norm_1_afa_norm_1/(P_v_norm_1*P_afa_norm_1));              


%% ����Ϣ��һ��
MI_v_beta_norm = MI_v_beta/MI_v_beta;
MI_v_betaRate_norm = MI_v_betaRate/MI_v_beta;
MI_v_vfa_norm = MI_v_vfa/MI_v_beta;       
MI_v_dfa_norm = MI_v_dfa /MI_v_beta;            
MI_v_afa_norm = MI_v_afa/MI_v_beta;