clc;
clear;
close all;


load test_y.mat;
load train_y.mat;
load estimated_windSVRTest.mat;
load estimated_windELMTest.mat;
load estimated_windBPNNTest.mat;
load estimated_windANFISTest.mat;


load estimated_windSVRTrain.mat;
load estimated_windELMTrain.mat;
load estimated_windBPNNTrain.mat;
load estimated_windANFISTrain.mat;
tarTrain = train_y;
tarTest = test_y;


n1 = length(train_y);
t1 = [0:0.04:400];
t = [400.04:0.04:800];
%% ѵ����Ч��չʾ
figure
hold on
box on %ʹ��figureͼ�е��ϱߺ��ұߵĿ̶��߳���
plot(t1, tarTrain, 'LineWidth',2);
plot(t1, estimated_windBPNNTrain,'g', 'LineWidth',2);
plot(t1, estimated_windANFISTrain,'k', 'LineWidth',2);
plot(t1, estimated_windELMTrain,'y', 'LineWidth',2);
plot(t1, estimated_windSVRTrain,'r', 'LineWidth',2);
legend('��ʵ����','NN (train)','ANFIS (train)','ELM (train)','SVR (train)');



RMSE_trainSVR = sqrt(sum((estimated_windSVRTrain - tarTrain).^2)/length(estimated_windSVRTrain));
RMSE_trainBPNN = sqrt(sum((estimated_windBPNNTrain - tarTrain).^2)/length(estimated_windBPNNTrain));
RMSE_trainELM = sqrt(sum((estimated_windELMTrain - tarTrain).^2)/length(estimated_windELMTrain));
RMSE_trainANFIS = sqrt(sum((estimated_windANFISTrain - tarTrain).^2)/length(estimated_windANFISTrain));


MAPE_trainSVR= sum(abs((tarTrain - estimated_windSVRTrain)./tarTrain ))*100/length( estimated_windSVRTrain);
MAPE_trainBPNN= sum(abs((tarTrain - estimated_windBPNNTrain)./tarTrain ))*100/length( estimated_windBPNNTrain);
MAPE_trainELM= sum(abs((tarTrain - estimated_windELMTrain)./tarTrain ))*100/length( estimated_windELMTrain);
MAPE_trainANFIS= sum(abs((tarTrain - estimated_windANFISTrain)./tarTrain ))*100/length( estimated_windANFISTrain);


MAE_trainSVR = sum(abs(tarTrain - estimated_windSVRTrain)) / length( estimated_windSVRTrain);
MAE_trainBPNN = sum(abs(tarTrain - estimated_windBPNNTrain)) / length( estimated_windBPNNTrain);
MAE_trainELM = sum(abs(tarTrain - estimated_windELMTrain)) / length( estimated_windELMTrain);
MAE_trainANFIS = sum(abs(tarTrain - estimated_windANFISTrain)) / length( estimated_windANFISTrain);


% STDE_trainSVR = std((tarTrain - estimated_windSVRTrain), 1);
% STDE_trainBPNN = std((tarTrain - estimated_windBPNNTrain), 1);
% STDE_trainELM = std((tarTrain - estimated_windELMTrain), 1);
% STDE_trainANFIS = std((tarTrain - estimated_windANFISTrain), 1);



PC_1 = n1*(sum(estimated_windSVRTrain.*tarTrain)) -  sum(estimated_windSVRTrain)*sum(tarTrain);
PC_2 = sqrt((n1*sum(estimated_windSVRTrain.^2)-sum(estimated_windSVRTrain)^2) * (n1*sum(tarTrain.^2)-sum(tarTrain)^2)); 
PC_trainSVR = PC_1 / PC_2;

PC_1 = n1*(sum(estimated_windBPNNTrain.*tarTrain)) -  sum(estimated_windBPNNTrain)*sum(tarTrain);
PC_2 = sqrt((n1*sum(estimated_windBPNNTrain.^2)-sum(estimated_windBPNNTrain)^2) * (n1*sum(tarTrain.^2)-sum(tarTrain)^2)); 
PC_trainBPNN = PC_1 / PC_2;

PC_1 = n1*(sum(estimated_windELMTrain.*tarTrain)) -  sum(estimated_windELMTrain)*sum(tarTrain);
PC_2 = sqrt((n1*sum(estimated_windELMTrain.^2)-sum(estimated_windELMTrain)^2) * (n1*sum(tarTrain.^2)-sum(tarTrain)^2)); 
PC_trainELM = PC_1 / PC_2;

PC_1 = n1*(sum(estimated_windANFISTrain.*tarTrain)) -  sum(estimated_windANFISTrain)*sum(tarTrain);
PC_2 = sqrt((n1*sum(estimated_windANFISTrain.^2)-sum(estimated_windANFISTrain)^2) * (n1*sum(tarTrain.^2)-sum(tarTrain)^2)); 
PC_trainANFIS = PC_1 / PC_2;



v1 = sum((estimated_windBPNNTrain - tarTrain).^2);
v2 = sum((tarTrain-mean(tarTrain)).^2);
DC_trainBPNN = 1 - v1 / v2;

v1 = sum((estimated_windELMTrain - tarTrain).^2);
v2 = sum((tarTrain-mean(tarTrain)).^2);
DC_trainELM = 1 - v1 / v2;
 
v1 = sum((estimated_windANFISTrain - tarTrain).^2);
v2 = sum((tarTrain-mean(tarTrain)).^2);
DC_trainANFIS = 1 - v1 / v2;

v1 = sum((estimated_windSVRTrain - tarTrain).^2);
v2 = sum((tarTrain-mean(tarTrain)).^2);
DC_trainSVR = 1 - v1 / v2;


%% ���Լ�Ч��չʾ
figure
hold on
box on %ʹ��figureͼ�е��ϱߺ��ұߵĿ̶��߳���
plot(t, tarTest, 'LineWidth',2);
plot(t, estimated_windBPNNTest,'g', 'LineWidth',2);
plot(t, estimated_windANFISTest,'k', 'LineWidth',2);
plot(t, estimated_windELMTest,'y', 'LineWidth',2);
plot(t, estimated_windSVRTest,'r', 'LineWidth',2);
legend('��ʵ����','NN (test)','ANFIS (test)','ELM (test)','SVR (test)');



RMSE_TestSVR = sqrt(sum((estimated_windSVRTest - tarTest).^2)/length(estimated_windSVRTest));
RMSE_TestBPNN = sqrt(sum((estimated_windBPNNTest - tarTest).^2)/length(estimated_windBPNNTest));
RMSE_TestELM = sqrt(sum((estimated_windELMTest - tarTest).^2)/length(estimated_windELMTest));
RMSE_TestANFIS = sqrt(sum((estimated_windANFISTest - tarTest).^2)/length(estimated_windANFISTest));


MAPE_TestSVR= sum(abs((tarTest - estimated_windSVRTest)./tarTest ))*100/length( estimated_windSVRTest);
MAPE_TestBPNN= sum(abs((tarTest - estimated_windBPNNTest)./tarTest ))*100/length( estimated_windBPNNTest);
MAPE_TestELM= sum(abs((tarTest - estimated_windELMTest)./tarTest ))*100/length( estimated_windELMTest);
MAPE_TestANFIS= sum(abs((tarTest - estimated_windANFISTest)./tarTest ))*100/length( estimated_windANFISTest);


MAE_TestSVR = sum(abs(tarTest - estimated_windSVRTest)) / length( estimated_windSVRTest);
MAE_TestBPNN = sum(abs(tarTest - estimated_windBPNNTest)) / length( estimated_windBPNNTest);
MAE_TestELM = sum(abs(tarTest - estimated_windELMTest)) / length( estimated_windELMTest);
MAE_TestANFIS = sum(abs(tarTest - estimated_windANFISTest)) / length( estimated_windANFISTest);


% STDE_TestSVR = std((tarTest - estimated_windSVRTest), 1);
% STDE_TestBPNN = std((tarTest - estimated_windBPNNTest), 1);
% STDE_TestELM = std((tarTest - estimated_windELMTest), 1);
% STDE_TestANFIS = std((tarTest - estimated_windANFISTest), 1);



PC_1 = n1*(sum(estimated_windSVRTest.*tarTest)) -  sum(estimated_windSVRTest)*sum(tarTest);
PC_2 = sqrt((n1*sum(estimated_windSVRTest.^2)-sum(estimated_windSVRTest)^2) * (n1*sum(tarTest.^2)-sum(tarTest)^2)); 
PC_TestSVR = PC_1 / PC_2;

PC_1 = n1*(sum(estimated_windBPNNTest.*tarTest)) -  sum(estimated_windBPNNTest)*sum(tarTest);
PC_2 = sqrt((n1*sum(estimated_windBPNNTest.^2)-sum(estimated_windBPNNTest)^2) * (n1*sum(tarTest.^2)-sum(tarTest)^2)); 
PC_TestBPNN = PC_1 / PC_2;

PC_1 = n1*(sum(estimated_windELMTest.*tarTest)) -  sum(estimated_windELMTest)*sum(tarTest);
PC_2 = sqrt((n1*sum(estimated_windELMTest.^2)-sum(estimated_windELMTest)^2) * (n1*sum(tarTest.^2)-sum(tarTest)^2)); 
PC_TestELM = PC_1 / PC_2;

PC_1 = n1*(sum(estimated_windANFISTest.*tarTest)) -  sum(estimated_windANFISTest)*sum(tarTest);
PC_2 = sqrt((n1*sum(estimated_windANFISTest.^2)-sum(estimated_windANFISTest)^2) * (n1*sum(tarTest.^2)-sum(tarTest)^2)); 
PC_TestANFIS = PC_1 / PC_2;



v1 = sum((estimated_windBPNNTest - tarTest).^2);
v2 = sum((tarTest-mean(tarTest)).^2);
DC_TestBPNN = 1 - v1 / v2;

v1 = sum((estimated_windELMTest - tarTest).^2);
v2 = sum((tarTest-mean(tarTest)).^2);
DC_TestELM = 1 - v1 / v2;
 
v1 = sum((estimated_windANFISTest - tarTest).^2);
v2 = sum((tarTest-mean(tarTest)).^2);
DC_TestANFIS = 1 - v1 / v2;

v1 = sum((estimated_windSVRTest - tarTest).^2);
v2 = sum((tarTest-mean(tarTest)).^2);
DC_TestSVR = 1 - v1 / v2;





