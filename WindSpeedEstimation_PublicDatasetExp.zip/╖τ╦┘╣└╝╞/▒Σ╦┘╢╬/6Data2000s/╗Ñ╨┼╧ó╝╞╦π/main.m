clc
clear 
close all



%% ��������
v=xlsread('wind.xls');
v = v(5:10005,2);

rotorSpeed=xlsread('rotorSpeed.xls');
rotorSpeed = rotorSpeed(5:10005,2);

dfa=xlsread('dfa.xls'); 
dfa = dfa(5:10005,2);

generatorSpeed=xlsread('generatorSpeed.xls'); 
generatorSpeed = generatorSpeed(5:10005,2);

vfa=xlsread('vfa.xls');
vfa = vfa(5:10005,2);

afa=xlsread('afa.xls'); 
afa = afa(5:10005,2);

generatorPower=xlsread('generatorPower.xls');
generatorPower = generatorPower(5:10005,2);


load generatorTorque.txt;
generatorTorque = generatorTorque(1:10001,2);

load rotorAzimuth.txt;
rotorAzimuth = rotorAzimuth(1:10001,2);

%% �����������й�һ������
n = length(v);
variables = [v rotorSpeed dfa generatorSpeed vfa afa generatorPower generatorTorque rotorAzimuth];
variables_norm = (variables - repmat(min(variables), n, 1)) ./ repmat((max(variables) - min(variables)), n, 1);%max()��ž���    
v_norm = variables_norm(:,1);
rotorSpeed_norm = variables_norm(:,2);
dfa_norm = variables_norm(:,3);
generatorSpeed_norm = variables_norm(:,4);
vfa_norm = variables_norm(:,5);
afa_norm = variables_norm(:,6);
generatorPower_norm = variables_norm(:,7);
generatorTorque_norm = variables_norm(:,8);
rotorAzimuth_norm = variables_norm(:,9);
%% ������ٺͷ���ת��֮��Ļ���Ϣ
num_v_norm_0 = 0;
num_v_norm_1 = 0;
for i = 1:n
    if v_norm(i) <= mean(v_norm)
        num_v_norm_0 = num_v_norm_0 +1;
    end 
     
    if v_norm(i) > mean(v_norm)
        num_v_norm_1 = num_v_norm_1 +1;
    end
end

num_rotorSpeed_norm_0 = 0;
num_rotorSpeed_norm_1 = 0;
for i = 1:n
    if rotorSpeed_norm(i) <= mean(rotorSpeed_norm)
        num_rotorSpeed_norm_0 = num_rotorSpeed_norm_0 +1;
    end 
     
    if rotorSpeed_norm(i) > mean(rotorSpeed_norm)
        num_rotorSpeed_norm_1 = num_rotorSpeed_norm_1 +1;
    end
end

U0 = num_v_norm_0 + num_rotorSpeed_norm_0;
U1 = num_v_norm_0 + num_rotorSpeed_norm_1;
U2 = num_v_norm_1 + num_rotorSpeed_norm_0;
U3 = num_v_norm_1 + num_rotorSpeed_norm_1;
L = U0 + U1 + U2 + U3;

P_v_norm_0 = (U0 + U1)/L;
P_v_norm_1 = (U2 + U3)/L;
P_rotorSpeed_norm_0 = (U0 + U2)/L;
P_rotorSpeed_norm_1 = (U1 + U3)/L;

P_v_norm_0_rotorSpeed_norm_0 = U0/L;
P_v_norm_1_rotorSpeed_norm_0 = U2/L;
P_v_norm_0_rotorSpeed_norm_1 = U1/L;
P_v_norm_1_rotorSpeed_norm_1 = U3/L;

MI_v_rotorSpeed = P_v_norm_0_rotorSpeed_norm_0 * log2(P_v_norm_0_rotorSpeed_norm_0/(P_v_norm_0*P_rotorSpeed_norm_0)) + ...
            P_v_norm_0_rotorSpeed_norm_1 * log2(P_v_norm_0_rotorSpeed_norm_1/(P_v_norm_0*P_rotorSpeed_norm_1)) + ...
            P_v_norm_1_rotorSpeed_norm_0 * log2(P_v_norm_1_rotorSpeed_norm_0/(P_v_norm_1*P_rotorSpeed_norm_0)) + ...
            P_v_norm_1_rotorSpeed_norm_1 * log2(P_v_norm_1_rotorSpeed_norm_1/(P_v_norm_1*P_rotorSpeed_norm_1)); 


        
%% ������ٺ�����ǰ��λ��֮��Ļ���Ϣ
num_v_norm_0 = 0;
num_v_norm_1 = 0;
for i = 1:n
    if v_norm(i) <= mean(v_norm)
        num_v_norm_0 = num_v_norm_0 +1;
    end 
     
    if v_norm(i) > mean(v_norm)
        num_v_norm_1 = num_v_norm_1 +1;
    end
end

num_dfa_norm_0 = 0;
num_dfa_norm_1 = 0;
for i = 1:n
    if dfa_norm(i) <= mean(dfa_norm)
        num_dfa_norm_0 = num_dfa_norm_0 +1;
    end 
     
    if dfa_norm(i) > mean(dfa_norm)
        num_dfa_norm_1 = num_dfa_norm_1 +1;
    end
end

U0 = num_v_norm_0 + num_dfa_norm_0;
U1 = num_v_norm_0 + num_dfa_norm_1;
U2 = num_v_norm_1 + num_dfa_norm_0;
U3 = num_v_norm_1 + num_dfa_norm_1;
L = U0 + U1 + U2 + U3;

P_v_norm_0 = (U0 + U1)/L;
P_v_norm_1 = (U2 + U3)/L;
P_dfa_norm_0 = (U0 + U2)/L;
P_dfa_norm_1 = (U1 + U3)/L;

P_v_norm_0_dfa_norm_0 = U0/L;
P_v_norm_1_dfa_norm_0 = U2/L;
P_v_norm_0_dfa_norm_1 = U1/L;
P_v_norm_1_dfa_norm_1 = U3/L;

MI_v_dfa = P_v_norm_0_dfa_norm_0 * log2(P_v_norm_0_dfa_norm_0/(P_v_norm_0*P_dfa_norm_0)) + ...
            P_v_norm_0_dfa_norm_1 * log2(P_v_norm_0_dfa_norm_1/(P_v_norm_0*P_dfa_norm_1)) + ...
            P_v_norm_1_dfa_norm_0 * log2(P_v_norm_1_dfa_norm_0/(P_v_norm_1*P_dfa_norm_0)) + ...
            P_v_norm_1_dfa_norm_1 * log2(P_v_norm_1_dfa_norm_1/(P_v_norm_1*P_dfa_norm_1));  
        

        
%% ������ٺͷ����ת��֮��Ļ���Ϣ
num_v_norm_0 = 0;
num_v_norm_1 = 0;
for i = 1:n
    if v_norm(i) <= mean(v_norm)
        num_v_norm_0 = num_v_norm_0 +1;
    end 
     
    if v_norm(i) > mean(v_norm)
        num_v_norm_1 = num_v_norm_1 +1;
    end
end

num_generatorSpeed_norm_0 = 0;
num_generatorSpeed_norm_1 = 0;
for i = 1:n
    if generatorSpeed_norm(i) <= mean(generatorSpeed_norm)
        num_generatorSpeed_norm_0 = num_generatorSpeed_norm_0 +1;
    end 
     
    if generatorSpeed_norm(i) > mean(generatorSpeed_norm)
        num_generatorSpeed_norm_1 = num_generatorSpeed_norm_1 +1;
    end
end

U0 = num_v_norm_0 + num_generatorSpeed_norm_0;
U1 = num_v_norm_0 + num_generatorSpeed_norm_1;
U2 = num_v_norm_1 + num_generatorSpeed_norm_0;
U3 = num_v_norm_1 + num_generatorSpeed_norm_1;
L = U0 + U1 + U2 + U3;

P_v_norm_0 = (U0 + U1)/L;
P_v_norm_1 = (U2 + U3)/L;
P_generatorSpeed_norm_0 = (U0 + U2)/L;
P_generatorSpeed_norm_1 = (U1 + U3)/L;

P_v_norm_0_generatorSpeed_norm_0 = U0/L;
P_v_norm_1_generatorSpeed_norm_0 = U2/L;
P_v_norm_0_generatorSpeed_norm_1 = U1/L;
P_v_norm_1_generatorSpeed_norm_1 = U3/L;

MI_v_generatorSpeed = P_v_norm_0_generatorSpeed_norm_0 * log2(P_v_norm_0_generatorSpeed_norm_0/(P_v_norm_0*P_generatorSpeed_norm_0)) + ...
                P_v_norm_0_generatorSpeed_norm_1 * log2(P_v_norm_0_generatorSpeed_norm_1/(P_v_norm_0*P_generatorSpeed_norm_1)) + ...
                P_v_norm_1_generatorSpeed_norm_0 * log2(P_v_norm_1_generatorSpeed_norm_0/(P_v_norm_1*P_generatorSpeed_norm_0)) + ...
                P_v_norm_1_generatorSpeed_norm_1 * log2(P_v_norm_1_generatorSpeed_norm_1/(P_v_norm_1*P_generatorSpeed_norm_1));              



%% ������ٺ�����ǰ���ٶ�֮��Ļ���Ϣ
num_v_norm_0 = 0;
num_v_norm_1 = 0;
for i = 1:n
    if v_norm(i) <= mean(v_norm)
        num_v_norm_0 = num_v_norm_0 +1;
    end 
     
    if v_norm(i) > mean(v_norm)
        num_v_norm_1 = num_v_norm_1 +1;
    end
end

num_vfa_norm_0 = 0;
num_vfa_norm_1 = 0;
for i = 1:n
    if vfa_norm(i) <= mean(vfa_norm)
        num_vfa_norm_0 = num_vfa_norm_0 +1;
    end 
     
    if vfa_norm(i) > mean(vfa_norm)
        num_vfa_norm_1 = num_vfa_norm_1 +1;
    end
end

U0 = num_v_norm_0 + num_vfa_norm_0;
U1 = num_v_norm_0 + num_vfa_norm_1;
U2 = num_v_norm_1 + num_vfa_norm_0;
U3 = num_v_norm_1 + num_vfa_norm_1;
L = U0 + U1 + U2 + U3;

P_v_norm_0 = (U0 + U1)/L;
P_v_norm_1 = (U2 + U3)/L;
P_vfa_norm_0 = (U0 + U2)/L;
P_vfa_norm_1 = (U1 + U3)/L;

P_v_norm_0_vfa_norm_0 = U0/L;
P_v_norm_1_vfa_norm_0 = U2/L;
P_v_norm_0_vfa_norm_1 = U1/L;
P_v_norm_1_vfa_norm_1 = U3/L;

MI_v_vfa = P_v_norm_0_vfa_norm_0 * log2(P_v_norm_0_vfa_norm_0/(P_v_norm_0*P_vfa_norm_0)) + ...
                P_v_norm_0_vfa_norm_1 * log2(P_v_norm_0_vfa_norm_1/(P_v_norm_0*P_vfa_norm_1)) + ...
                P_v_norm_1_vfa_norm_0 * log2(P_v_norm_1_vfa_norm_0/(P_v_norm_1*P_vfa_norm_0)) + ...
                P_v_norm_1_vfa_norm_1 * log2(P_v_norm_1_vfa_norm_1/(P_v_norm_1*P_vfa_norm_1));              



%% ������ٺ�����ǰ����ٶ�֮��Ļ���Ϣ
num_v_norm_0 = 0;
num_v_norm_1 = 0;
for i = 1:n
    if v_norm(i) <= mean(v_norm)
        num_v_norm_0 = num_v_norm_0 +1;
    end 
     
    if v_norm(i) > mean(v_norm)
        num_v_norm_1 = num_v_norm_1 +1;
    end
end

num_afa_norm_0 = 0;
num_afa_norm_1 = 0;
for i = 1:n
    if afa_norm(i) <= mean(afa_norm)
        num_afa_norm_0 = num_afa_norm_0 +1;
    end 
     
    if afa_norm(i) > mean(afa_norm)
        num_afa_norm_1 = num_afa_norm_1 +1;
    end
end

U0 = num_v_norm_0 + num_afa_norm_0;
U1 = num_v_norm_0 + num_afa_norm_1;
U2 = num_v_norm_1 + num_afa_norm_0;
U3 = num_v_norm_1 + num_afa_norm_1;
L = U0 + U1 + U2 + U3;

P_v_norm_0 = (U0 + U1)/L;
P_v_norm_1 = (U2 + U3)/L;
P_afa_norm_0 = (U0 + U2)/L;
P_afa_norm_1 = (U1 + U3)/L;

P_v_norm_0_afa_norm_0 = U0/L;
P_v_norm_1_afa_norm_0 = U2/L;
P_v_norm_0_afa_norm_1 = U1/L;
P_v_norm_1_afa_norm_1 = U3/L;

MI_v_afa = P_v_norm_0_afa_norm_0 * log2(P_v_norm_0_afa_norm_0/(P_v_norm_0*P_afa_norm_0)) + ...
                P_v_norm_0_afa_norm_1 * log2(P_v_norm_0_afa_norm_1/(P_v_norm_0*P_afa_norm_1)) + ...
                P_v_norm_1_afa_norm_0 * log2(P_v_norm_1_afa_norm_0/(P_v_norm_1*P_afa_norm_0)) + ...
                P_v_norm_1_afa_norm_1 * log2(P_v_norm_1_afa_norm_1/(P_v_norm_1*P_afa_norm_1));              

%% ������ٺͷ��繦��֮��Ļ���Ϣ
num_v_norm_0 = 0;
num_v_norm_1 = 0;
for i = 1:n
    if v_norm(i) <= mean(v_norm)
        num_v_norm_0 = num_v_norm_0 +1;
    end 
     
    if v_norm(i) > mean(v_norm)
        num_v_norm_1 = num_v_norm_1 +1;
    end
end

num_generatorPower_norm_0 = 0;
num_generatorPower_norm_1 = 0;
for i = 1:n
    if generatorPower_norm(i) <= mean(generatorPower_norm)
        num_generatorPower_norm_0 = num_generatorPower_norm_0 +1;
    end 
     
    if generatorPower_norm(i) > mean(generatorPower_norm)
        num_generatorPower_norm_1 = num_generatorPower_norm_1 +1;
    end
end

U0 = num_v_norm_0 + num_generatorPower_norm_0;
U1 = num_v_norm_0 + num_generatorPower_norm_1;
U2 = num_v_norm_1 + num_generatorPower_norm_0;
U3 = num_v_norm_1 + num_generatorPower_norm_1;
L = U0 + U1 + U2 + U3;

P_v_norm_0 = (U0 + U1)/L;
P_v_norm_1 = (U2 + U3)/L;
P_generatorPower_norm_0 = (U0 + U2)/L;
P_generatorPower_norm_1 = (U1 + U3)/L;

P_v_norm_0_generatorPower_norm_0 = U0/L;
P_v_norm_1_generatorPower_norm_0 = U2/L;
P_v_norm_0_generatorPower_norm_1 = U1/L;
P_v_norm_1_generatorPower_norm_1 = U3/L;

MI_v_generatorPower = P_v_norm_0_generatorPower_norm_0 * log2(P_v_norm_0_generatorPower_norm_0/(P_v_norm_0*P_generatorPower_norm_0)) + ...
                P_v_norm_0_generatorPower_norm_1 * log2(P_v_norm_0_generatorPower_norm_1/(P_v_norm_0*P_generatorPower_norm_1)) + ...
                P_v_norm_1_generatorPower_norm_0 * log2(P_v_norm_1_generatorPower_norm_0/(P_v_norm_1*P_generatorPower_norm_0)) + ...
                P_v_norm_1_generatorPower_norm_1 * log2(P_v_norm_1_generatorPower_norm_1/(P_v_norm_1*P_generatorPower_norm_1));   
    
%% ������ٺ͵��ת��֮��Ļ���Ϣ
num_v_norm_0 = 0;
num_v_norm_1 = 0;
for i = 1:n
    if v_norm(i) <= mean(v_norm)
        num_v_norm_0 = num_v_norm_0 +1;
    end 
     
    if v_norm(i) > mean(v_norm)
        num_v_norm_1 = num_v_norm_1 +1;
    end
end

num_generatorTorque_norm_0 = 0;
num_generatorTorque_norm_1 = 0;
for i = 1:n
    if generatorTorque_norm(i) <= mean(generatorTorque_norm)
        num_generatorTorque_norm_0 = num_generatorTorque_norm_0 +1;
    end 
     
    if generatorTorque_norm(i) > mean(generatorTorque_norm)
        num_generatorTorque_norm_1 = num_generatorTorque_norm_1 +1;
    end
end

U0 = num_v_norm_0 + num_generatorTorque_norm_0;
U1 = num_v_norm_0 + num_generatorTorque_norm_1;
U2 = num_v_norm_1 + num_generatorTorque_norm_0;
U3 = num_v_norm_1 + num_generatorTorque_norm_1;
L = U0 + U1 + U2 + U3;

P_v_norm_0 = (U0 + U1)/L;
P_v_norm_1 = (U2 + U3)/L;
P_generatorTorque_norm_0 = (U0 + U2)/L;
P_generatorTorque_norm_1 = (U1 + U3)/L;

P_v_norm_0_generatorTorque_norm_0 = U0/L;
P_v_norm_1_generatorTorque_norm_0 = U2/L;
P_v_norm_0_generatorTorque_norm_1 = U1/L;
P_v_norm_1_generatorTorque_norm_1 = U3/L;

MI_v_generatorTorque = P_v_norm_0_generatorTorque_norm_0 * log2(P_v_norm_0_generatorTorque_norm_0/(P_v_norm_0*P_generatorTorque_norm_0)) + ...
                P_v_norm_0_generatorTorque_norm_1 * log2(P_v_norm_0_generatorTorque_norm_1/(P_v_norm_0*P_generatorTorque_norm_1)) + ...
                P_v_norm_1_generatorTorque_norm_0 * log2(P_v_norm_1_generatorTorque_norm_0/(P_v_norm_1*P_generatorTorque_norm_0)) + ...
                P_v_norm_1_generatorTorque_norm_1 * log2(P_v_norm_1_generatorTorque_norm_1/(P_v_norm_1*P_generatorTorque_norm_1));  
            
%% ������ٺ�Ҷ�ַ�λ��֮��Ļ���Ϣ
num_v_norm_0 = 0;
num_v_norm_1 = 0;
for i = 1:n
    if v_norm(i) <= mean(v_norm)
        num_v_norm_0 = num_v_norm_0 +1;
    end 
     
    if v_norm(i) > mean(v_norm)
        num_v_norm_1 = num_v_norm_1 +1;
    end
end

num_rotorAzimuth_norm_0 = 0;
num_rotorAzimuth_norm_1 = 0;
for i = 1:n
    if rotorAzimuth_norm(i) <= mean(rotorAzimuth_norm)
        num_rotorAzimuth_norm_0 = num_rotorAzimuth_norm_0 +1;
    end 
     
    if rotorAzimuth_norm(i) > mean(rotorAzimuth_norm)
        num_rotorAzimuth_norm_1 = num_rotorAzimuth_norm_1 +1;
    end
end

U0 = num_v_norm_0 + num_rotorAzimuth_norm_0;
U1 = num_v_norm_0 + num_rotorAzimuth_norm_1;
U2 = num_v_norm_1 + num_rotorAzimuth_norm_0;
U3 = num_v_norm_1 + num_rotorAzimuth_norm_1;
L = U0 + U1 + U2 + U3;

P_v_norm_0 = (U0 + U1)/L;
P_v_norm_1 = (U2 + U3)/L;
P_rotorAzimuth_norm_0 = (U0 + U2)/L;
P_rotorAzimuth_norm_1 = (U1 + U3)/L;

P_v_norm_0_rotorAzimuth_norm_0 = U0/L;
P_v_norm_1_rotorAzimuth_norm_0 = U2/L;
P_v_norm_0_rotorAzimuth_norm_1 = U1/L;
P_v_norm_1_rotorAzimuth_norm_1 = U3/L;

MI_v_rotorAzimuth = P_v_norm_0_rotorAzimuth_norm_0 * log2(P_v_norm_0_rotorAzimuth_norm_0/(P_v_norm_0*P_rotorAzimuth_norm_0)) + ...
                P_v_norm_0_rotorAzimuth_norm_1 * log2(P_v_norm_0_rotorAzimuth_norm_1/(P_v_norm_0*P_rotorAzimuth_norm_1)) + ...
                P_v_norm_1_rotorAzimuth_norm_0 * log2(P_v_norm_1_rotorAzimuth_norm_0/(P_v_norm_1*P_rotorAzimuth_norm_0)) + ...
                P_v_norm_1_rotorAzimuth_norm_1 * log2(P_v_norm_1_rotorAzimuth_norm_1/(P_v_norm_1*P_rotorAzimuth_norm_1));  
                        
%% ����Ϣ��һ��
MI_v_rotorSpeed_norm = MI_v_rotorSpeed/MI_v_generatorPower;
MI_v_generatorSpeed_norm = MI_v_generatorSpeed/MI_v_generatorPower;
MI_v_vfa_norm = MI_v_vfa/MI_v_generatorPower;       
MI_v_dfa_norm = MI_v_dfa /MI_v_generatorPower;            
MI_v_afa_norm = MI_v_afa/MI_v_generatorPower;
MI_v_generatorTorque_norm = MI_v_generatorTorque/MI_v_generatorPower;
MI_v_rotorAzimuth_norm = MI_v_rotorAzimuth/MI_v_generatorPower;
MI_v_generatorPower_norm = MI_v_generatorPower/MI_v_generatorPower;
