clc;
clear; 
close all;