clc;
clear;
close all;