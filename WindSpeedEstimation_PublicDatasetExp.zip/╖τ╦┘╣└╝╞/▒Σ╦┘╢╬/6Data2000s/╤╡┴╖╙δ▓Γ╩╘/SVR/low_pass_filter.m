function y = low_pass_filter(x)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
N=length(x);
lpf(1)=x(1);


% ��ͨ
for i=2:N
    
        lpf(i)=lpf(i-1)+0.01*(x(i)-lpf(i-1));
    
end



y=lpf';
end