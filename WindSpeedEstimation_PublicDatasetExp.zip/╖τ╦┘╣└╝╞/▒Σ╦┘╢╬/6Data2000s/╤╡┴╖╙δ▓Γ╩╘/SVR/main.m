clc;
clear all; 
close all;
%% ��������
v  = xlsread('wind.xls');

Pg = xlsread('generatorPower.xls');
load generatorTorque.txt;
Tem = generatorTorque;
wr = xlsread('rotorSpeed.xls');
wg = xlsread('generatorSpeed.xls');
dfa = xlsread('dfa.xls');

%% ��ȡѵ�����ݺͲ�������
v_train = v(1:10001,2);
v_test = v(10002:20001,2);


Pg_train = Pg(1:10001,2);
Pg_test = Pg(10002:20001,2);

Tem_train = Tem(1:10001,2);
Tem_test = Tem(10002:20001,2);

wr_train = wr(1:10001,2);
wr_test = wr(10002:20001,2);

wg_train = wg(1:10001,2);
wg_test = wg(10002:20001,2);

dfa_train = dfa(1:10001,2);
dfa_test = dfa(10002:20001,2);

%��һ�������Լ��������Сֵ��ѵ������ͬ
n_train = length(v_train);
n_test = length(v_test);

train_x = [Pg_train Tem_train wr_train wg_train dfa_train];
train_x_norm = (train_x - repmat(min(train_x), n_train, 1))./ repmat((max(train_x) - min(train_x)), n_train, 1);
train_y = v_train;
save train_x_norm train_x_norm;
save train_y train_y;

test_x = [Pg_test Tem_test wr_test wg_test dfa_test];
test_x_norm = (test_x - repmat(min(train_x), n_test, 1))./ repmat((max(train_x) - min(train_x)), n_test, 1);
test_y = v_test;
save test_x_norm test_x_norm;
save test_y test_y;

%% ʹ��PSO�㷨ѡ��SVR����,ѵ�������SVM
% fprintf('Choose c and g using pso..\n')
% [bestCVmse,bestc,bestg,pso_option] = psoSVMcgForRegress(tarTrain,trainFeaNorm);
% fprintf('Done...\n');%


cmd = ['-s 3 -t 2  -p 0.01',' -c ',num2str(10.0059 ),' -g ',num2str(0.0055)];    %10.0774      0.5299
model = svmtrain(train_y,train_x_norm,cmd);%-s 3 e-SVR;0
[predicted_value_train] = svmpredict(train_y,train_x_norm,model);
[predicted_value_test] = svmpredict(test_y,test_x_norm,model);

estimated_windSVRTest = low_pass_filter(predicted_value_test);  
estimated_windSVRTrain = low_pass_filter(predicted_value_train);

save estimated_windSVRTest estimated_windSVRTest;
save estimated_windSVRTrain estimated_windSVRTrain;


t_train = [0:0.04:400];
t_test = [400.04:0.04:800];

figure
plot(t_train, train_y);
hold on
plot(t_train, estimated_windSVRTrain,'r', 'lineWidth', 1.2);
xlabel('Time (s)');
ylabel('Wind Speed (m/s)');
legend('������ʵֵ (ѵ��)','���ٹ���ֵ (ѵ��)');



figure
plot(t_test, test_y);
hold on
plot(t_test, estimated_windSVRTest,'r' ,'lineWidth', 1.2);
xlabel('Time (s)');
ylabel('Wind Speed (m/s)');
legend('������ʵֵ (����)','���ٹ���ֵ (����)');





